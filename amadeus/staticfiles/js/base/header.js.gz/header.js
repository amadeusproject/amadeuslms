$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip(); //activate tooltip on all elements that has attribute data-toggle
});